
#import <Foundation/Foundation.h>

@protocol imageClickDelegate <NSObject>

-(void)mViewControllerShouldPush:(DramaModel *)reItem;

@end
