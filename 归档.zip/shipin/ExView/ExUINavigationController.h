//
//  ExUINavigationController.h
//  livenews
//
//  Created by dust on 14-11-7.
//
//

#import <UIKit/UIKit.h>

@interface ExUINavigationController : UINavigationController

@end
