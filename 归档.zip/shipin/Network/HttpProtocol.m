//
// Created by 祥龙 on 15/8/14.
// Copyright (c) 2015 kinstalk.com. All rights reserved.
//

#import "HttpProtocol.h"


@implementation HttpProtocol {

}
@end