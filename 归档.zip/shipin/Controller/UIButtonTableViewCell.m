//
//  UIButtonTableViewCell.m
//  shipin
//
//  Created by Mapollo27 on 15/8/19.
//  Copyright (c) 2015年 dust.zhang. All rights reserved.
//

#import "UIButtonTableViewCell.h"

@implementation UIButtonTableViewCell


- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self)
    {
//        UIButton *btnAdd = [[UIButton alloc ] initWithFrame:CGRectMake(20, 20, SCREEN_WIDTH-40, 40)];
//        [btnAdd setTitle:@"确认添加" forState:UIControlStateNormal];
//        btnAdd.titleLabel.font = [UIFont systemFontOfSize:14];
//        [btnAdd  setBackgroundColor:yellowRgb];
//        btnAdd.layer.masksToBounds = YES;
//        btnAdd.layer.cornerRadius = 3;
//        [btnAdd addTarget:self action:@selector(onButtonAdd) forControlEvents:UIControlEventTouchUpInside];
//        [self addSubview:btnAdd];
    }
    return self;
}


@end
