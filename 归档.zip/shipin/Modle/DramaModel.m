//
// Created by 祥龙 on 15/8/14.
// Copyright (c) 2015 dust.zhang. All rights reserved.
//

#import "DramaModel.h"
#import "DramaPostersModel.h"


@implementation DramaModel {

}
@end


@implementation DramaOpModel

NSNumber<Optional> *collects; //关注数
NSNumber<Optional> *clicks; //阅读数

@end

