//
//  FilmModel
//  movikr
//
//  Created by dust on 15/6/18.
//  Copyright (c) 2015年 movikr. All rights reserved.
//

#import "FilmModel.h"



@implementation TextModel

NSString        *strLeftName;
NSString        *strRightName;

@end



