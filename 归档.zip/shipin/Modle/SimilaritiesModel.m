//
// Created by 祥龙 on 15/8/14.
// Copyright (c) 2015 dust.zhang. All rights reserved.
//

#import "SimilaritiesModel.h"


@implementation SimilaritiesModel {

}
@end